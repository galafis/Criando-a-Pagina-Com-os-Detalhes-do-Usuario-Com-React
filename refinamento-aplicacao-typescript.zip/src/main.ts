import { soma, subtrai, multiplica, divide } from './index';

console.log("Soma: ", soma(10, 5));
console.log("Subtração: ", subtrai(10, 5));
console.log("Multiplicação: ", multiplica(10, 5));
console.log("Divisão: ", divide(10, 5));